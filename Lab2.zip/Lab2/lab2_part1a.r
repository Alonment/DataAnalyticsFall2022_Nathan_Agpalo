# Part 1A: Measures of Central Tendencies/Histograms/Data Manipulation

EPI_DATA = read.csv("./DA_Files/EPI/EPI_DATA.csv")

head(EPI_DATA)

# Calculating central tendency for EPI and DALY variables
mean(EPI_DATA$EPI, na.rm=TRUE)
median(EPI_DATA$EPI, na.rm=TRUE)
mode = sort(table(EPI_DATA$EPI), decreasing=TRUE)[1]
mode

mean(EPI_DATA$DALY, na.rm=TRUE)
median(EPI_DATA$DALY, na.rm=TRUE)
mode = sort(table(EPI_DATA$DALY), decreasing=TRUE)[1]
mode

library(ggplot2)

# Displaying box plots for EPI and DALY variables
fivenum(EPI_DATA$EPI)
ggplot(EPI_DATA, aes(y=EPI)) + geom_boxplot()

fivenum(EPI_DATA$DALY)
ggplot(EPI_DATA, aes(y=DALY)) + geom_boxplot()


# Calculating central tendency for NOX_pt and SO2_pt variables
mean(EPI_DATA$NOX_pt, na.rm=TRUE)
median(EPI_DATA$NOX_pt, na.rm=TRUE)
mode = sort(table(EPI_DATA$NOX_pt), decreasing=TRUE)[1]
mode

mean(EPI_DATA$SO2_pt, na.rm=TRUE)
median(EPI_DATA$SO2_pt, na.rm=TRUE)
mode = sort(table(EPI_DATA$SO2_pt), decreasing=TRUE)[1]
mode

# Displaying box plots for EPI and DALY variables
fivenum(EPI_DATA$OZONE_pt)
ggplot(EPI_DATA, aes(y=OZONE_pt)) + geom_boxplot()

fivenum(EPI_DATA$WQI_pt)
ggplot(EPI_DATA, aes(y=WQI_pt)) + geom_boxplot()


# Calculating central tendency for CLIMATE and AGRICULTURE variables
mean(EPI_DATA$CLIMATE, na.rm=TRUE)
median(EPI_DATA$CLIMATE, na.rm=TRUE)
mode = sort(table(EPI_DATA$CLIMATE), decreasing=TRUE)[1]
mode

mean(EPI_DATA$AGRICULTURE, na.rm=TRUE)
median(EPI_DATA$AGRICULTURE, na.rm=TRUE)
mode = sort(table(EPI_DATA$AGRICULTURE), decreasing=TRUE)[1]
mode

fivenum(EPI_DATA$FISHERIES)
ggplot(EPI_DATA, aes(y=FISHERIES)) + geom_boxplot()

fivenum(EPI_DATA$NMVOC_pt)
ggplot(EPI_DATA, aes(y=NMVOC_pt)) + geom_boxplot()

fivenum(EPI_DATA$ENVHEALTH)
fivenum(EPI_DATA$ECOSYSTEM)

boxplot(EPI_DATA[, c("ENVHEALTH", "ECOSYSTEM")])
qqplot(EPI_DATA$ENVHEALTH, EPI_DATA$ECOSYSTEM)

