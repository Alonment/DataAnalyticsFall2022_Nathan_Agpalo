# Part 1b: Regression Exercises

EPI_DATA = read.csv("./DA_Files/EPI/EPI_DATA.csv")
EPI_DATA = na.omit(EPI_DATA)
colnames(EPI_DATA)

attach(EPI_DATA)
boxplot(ENVHEALTH, DALY, AIR_H, WATER_H)
# Let's remove senseless metadata from our training data
EPI_DATA[6:length(EPI_DATA)]
model = lm(EPI ~ ., data=EPI_DATA[6:length(EPI_DATA)])

# Determine the coefficient that is most important in determining 
# ANSWER: Climate
model$coefficients[which.max(model$coefficients)]

lmENVH = lm(ENVHEALTH~DALY+AIR_H+WATER_H)
lmENVH
summary(lmENVH)
coeffsENVH = coef(lmENVH)
coeffsENVH

newDALY = c(seq(5, 95, 5))
newAIR_H = c(seq(5, 95, 5))
newWATER_H = c(seq(5, 95, 5))
newDF = data.frame(newDALY, newAIR_H, newWATER_H)

head(newDF)
dim(newDF)
pENV = predict(lmENVH, newDF, interval="prediction")
pENV
cENV = predict(lmENVH, newDF, interval="confidence")
cENV

lmAIR_E = lm(AIR_E ~ DALY+AIR_H+WATER_H)

summary(lmAIR_E)
coef(lmAIR_E)

pAIR_E = predict(lmAIR_E, newDF, interval="prediction")
pAIR_E
cAIR_E = predict(lmAIR_E, newDF, interval="confidence")
cAIR_E

lmCLIMATE = lm(CLIMATE ~ DALY+AIR_H+WATER_H)

summary(lmCLIMATE)
coef(lmCLIMATE)

pCLIMATE = predict(lmCLIMATE, newDF, interval="prediction")
pCLIMATE
cCLIMATE = predict(lmCLIMATE, newDF, interval="confidence")
cCLIMATE
