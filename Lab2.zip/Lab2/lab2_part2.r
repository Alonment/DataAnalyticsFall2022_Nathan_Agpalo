abalone_df = read.csv("./DA_Files/abalone.csv")
multiple_regression_df = read.csv("./DA_Files/dataset_multipleRegression.csv")

# Exercise 1: Regression

dim(multiple_regression_df)
colnames(multiple_regression_df)
head(multiple_regression_df)
summary(multiple_regression_df)

attach(multiple_regression_df)

lmROLL = lm(ROLL ~ UNEM + HGRAD, data=multiple_regression_df)
lmROLL$coefficients

?predict
lmROLL(1, 2)

# Predict ENROLLMENT if UNEMPLOYMENT IS 7% and HGRAD IS 90,000
dataPoint = data.frame(UNEM=7.0, HGRAD=90000)
predict(lmROLL, dataPoint) # PREDICTED ROLL = 91437.04

lmROLL = lm(ROLL ~ UNEM + HGRAD + INC, data=multiple_regression_df)
lmROLL$coefficients

# PREDICT ENROLLMENT if UNEMPLOYMENT=7.0, HGRAD=90000, and INC=25000
dataPoint = data.frame(UNEM=7.0, HGRAD=90000, INC=25000)
predict(lmROLL, dataPoint) # PREDICTED ROLL = 137.452.6

# Exercise 2: Classification

attach(abalone_df)
summary(abalone_df)

head(abalone_df)

require(kknn)

n = dim(abalone_df)[1]
intervals = c(train=0.85, val=0.15)

?cut
?seq
cumsum(c(0, intervals))
groups = sample(cut(seq(n), n*cumsum(c(0, intervals)), labels=names(intervals)))

sets = split(abalone_df, groups)
dim(sets$train)
dim(sets$val)

?kknn
?train.kknn
colnames(abalone_df)
model = train.kknn(Rings ~ ., sets$train, kmax=50)
table(round(predict(model, sets$val)), (sets$val)$Rings)

summary(model)


# Exercise 3: Clustering

library(ggplot2)
data("iris")
head(iris)

iris_df = iris[, c(1:4)]

summary(iris_df)

?dist

?rainbow
?kmeans

set.seed(500)

ggplot(iris,aes(x = Sepal.Length, y = Sepal.Width, col= Species)) + geom_point()
ggplot(iris,aes(x = Petal.Length, y = Petal.Width, col= Species)) + geom_point()

k.max = 21

wss<- sapply(1:k.max,function(k){kmeans(iris[,3:4],k,nstart = 20,iter.max = 20)$tot.withinss})
wss # within sum of squares.
plot(1:k.max,wss, type= "b", xlab = "Number of clusters(k)", ylab = "Within cluster sum of squares")

clusters = kmeans(iris_df, 3, iter.max=5000, nstart=20)
table(clusters$cluster, iris$Species)
plot(iris_df, col=clusters$cluster)
